namespace Bullseye.Internal
{
    public enum Host
    {
        Unknown,
        Appveyor,
        AzurePipelines,
        Travis,
        TeamCity,
    }
}
