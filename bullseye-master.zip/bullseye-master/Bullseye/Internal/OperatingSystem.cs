namespace Bullseye.Internal
{
    public enum OperatingSystem
    {
        Unknown,
        Windows,
        Linux,
        MacOS,
    }
}
